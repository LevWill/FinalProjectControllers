﻿using FinalProjectControllers.Models;
using Microsoft.EntityFrameworkCore;
using TeamInfoApi.Models;

namespace TeamInfoApi.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<TeamMember> TeamMembers { get; set; }
        public DbSet<Hobby> Hobbies { get; set; }
        public DbSet<BreakfastFood> BreakfastFoods { get; set; }
        public DbSet<Pet> Pets { get; set; }
    }
}