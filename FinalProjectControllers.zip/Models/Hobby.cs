﻿namespace TeamInfoApi.Models
{
    public class Hobby
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public int YearsPracticed { get; set; }
        public string? SkillLevel { get; set; }
    }
}